<template>
  <div class="hello">
    <div id="zyb"></div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  //钩子函数
  mounted() {
    this.draw();
  },
  methods: {
    draw() {
      // 初始化echarts实例
      let zYb = this.$echarts.init(document.getElementById("zyb"));
      // 绘制图表
      var option = {
        tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
        orient: 'vertical',
        top:100,
        left: 800,
        data: ['考点专练', '套卷练习', '仿真模考', ]
    },
    series: [
        {
            name: '访问来源',
            type: 'pie',
            radius: ['45%', '90%'],
            avoidLabelOverlap: false,
            label: {
                show: false,
                position: 'center'
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: '50',
                    fontWeight: 'bold'
                    
                }
            },
            labelLine: {
                show: false
            },
            data: [
                {value: 150, name: '考点专练'},
                {value: 150, name: '套卷练习'},
                {value: 150, name: '仿真模考'},
                
            ],
            itemStyle: {
              normal: {
                color: function(params) {
                  let colorList = [
                    "#f5b26c",
                    "#54bbab",
                    "#a3e9a5",
                    "#f5b26c",
                    "#f5b26c",
                    "#f5b26c"
                  ];
                  return colorList[params.dataIndex];
                }
              }
            }
        }
    ]
      };
      //防止越界，重绘canvas
      window.onresize = zYb.resize;
      zYb.setOption(option); //设置option
    }
  }
};
</script>


<style scoped>
#zyb{
  width: 1000px;
  height: 600px;
}
</style>
